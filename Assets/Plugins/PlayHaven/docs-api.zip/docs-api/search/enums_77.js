var searchData=
[
  ['whentogetnotifications',['WhenToGetNotifications',['../class_play_haven_manager.html#ae80f3675e48de15b6b47828993edcef8',1,'PlayHavenManager']]],
  ['whentoopen',['WhenToOpen',['../class_play_haven_manager.html#a855cadcaacef4d8d1f2b9ffae2e1a981',1,'PlayHavenManager']]],
  ['whentoregisterforpushnotifications',['WhenToRegisterForPushNotifications',['../class_play_haven_manager.html#a14a179a4259fff3038618464359ef07c',1,'PlayHavenManager']]],
  ['whentorequest',['WhenToRequest',['../class_play_haven_1_1_play_haven_content_requester.html#a4fd5662a9a85d9d4d643506faf972424',1,'PlayHaven::PlayHavenContentRequester']]]
];
