var searchData=
[
  ['deregisterfrompushnofications',['DeregisterFromPushNofications',['../class_play_haven_manager.html#ac0400acf0c3b09daa7466a8025a96ce0',1,'PlayHavenManager']]],
  ['diddisplaycontenthandler',['DidDisplayContentHandler',['../namespace_play_haven.html#a11acd4b749eb926be5836f5a87fb4144',1,'PlayHaven']]],
  ['dismisshandler',['DismissHandler',['../class_play_haven_manager.html#abc239c38900cff9020c57323a7d85e0a',1,'PlayHavenManager.DismissHandler()'],['../namespace_play_haven.html#a2d8917cac3f9a2235a22915475dfaa72',1,'PlayHaven.DismissHandler()']]]
];
