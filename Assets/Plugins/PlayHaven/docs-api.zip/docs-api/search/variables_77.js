var searchData=
[
  ['whentogetnotifications',['whenToGetNotifications',['../class_play_haven_manager.html#a506f4580733c2115bb4b5fbfe46fa00c',1,'PlayHavenManager']]],
  ['whentorequest',['whenToRequest',['../class_play_haven_1_1_play_haven_content_requester.html#ac432197342d1ee806699a3fdc61b4405',1,'PlayHaven::PlayHavenContentRequester']]],
  ['whentosendopen',['whenToSendOpen',['../class_play_haven_manager.html#a6097a56e7950487053d4c60b5b46d8e3',1,'PlayHavenManager']]]
];
