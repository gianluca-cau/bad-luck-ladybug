var searchData=
[
  ['purchaseresolution',['PurchaseResolution',['../namespace_play_haven.html#a799bf84bd85366bf88c265c5051505a1',1,'PlayHaven']]]
];
