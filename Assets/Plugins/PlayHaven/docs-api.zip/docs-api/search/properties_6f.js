var searchData=
[
  ['optoutstatus',['OptOutStatus',['../class_play_haven_manager.html#a96f9e121fa9d72618bc9169a955ed8d8',1,'PlayHavenManager']]]
];
