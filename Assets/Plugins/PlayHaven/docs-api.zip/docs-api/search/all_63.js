var searchData=
[
  ['cancelallonlevelload',['cancelAllOnLevelLoad',['../class_play_haven_manager.html#ae9ececf71333b85cff88a8d1b913b93f',1,'PlayHavenManager']]],
  ['cancelled',['Cancelled',['../namespace_play_haven.html#a799bf84bd85366bf88c265c5051505a1aa149e85a44aeec9140e92733d9ed694e',1,'PlayHaven']]],
  ['cancelrequesthandler',['CancelRequestHandler',['../class_play_haven_manager.html#a4ee670c69266b72a26da610b6ea6887a',1,'PlayHavenManager']]],
  ['carriernetworkonly',['CarrierNetworkOnly',['../class_play_haven_1_1_play_haven_content_requester.html#ad02e8ddbc94cc6e0858dc76d91626e83ad5e7338113aa8632869ec0b3286ac22d',1,'PlayHaven::PlayHavenContentRequester']]],
  ['clearbadge',['ClearBadge',['../class_play_haven_manager.html#a1c8c2012d77b9fc203f067121a5dd657',1,'PlayHavenManager']]],
  ['code',['code',['../class_play_haven_1_1_error.html#a6ef41e95d72c0b9c638f80329ee688f2',1,'PlayHaven::Error']]],
  ['connectionforprefetch',['connectionForPrefetch',['../class_play_haven_1_1_play_haven_content_requester.html#a318010da704db3bc351ec2fe221acad5',1,'PlayHaven::PlayHavenContentRequester']]],
  ['content',['Content',['../namespace_play_haven.html#aac76f50c8e062fce56e0f33a923f3760af15c1cae7882448b3fb0404682e17e61',1,'PlayHaven']]],
  ['contentpreloadrequest',['ContentPreloadRequest',['../class_play_haven_manager.html#a87b57eb36acc2ed8b180b6407c603004',1,'PlayHavenManager']]],
  ['contentrequest',['ContentRequest',['../class_play_haven_manager.html#a457076c4951586ed5aba1ab2882645fe',1,'PlayHavenManager.ContentRequest(string placement)'],['../class_play_haven_manager.html#aef40de38bc3590282efbc291bb47ec7e',1,'PlayHavenManager.ContentRequest(string placement, bool showsOverlayImmediately)']]],
  ['crosspromotionwidget',['CrossPromotionWidget',['../namespace_play_haven.html#aac76f50c8e062fce56e0f33a923f3760a7b963b8f111c15afeb1b2fff9a05d8f2',1,'PlayHaven']]],
  ['customudid',['CustomUDID',['../class_play_haven_manager.html#a8999631639228de37ac988c8022edb7d',1,'PlayHavenManager']]]
];
