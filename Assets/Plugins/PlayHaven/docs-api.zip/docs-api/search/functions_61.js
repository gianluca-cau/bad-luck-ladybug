var searchData=
[
  ['apnsdidfailtoregisterhandler',['APNSDidFailToRegisterHandler',['../class_play_haven_manager.html#a7abac2046bc89b5fe2a7833e0ef690cd',1,'PlayHavenManager']]],
  ['apnsdidregisterhandler',['APNSDidRegisterHandler',['../class_play_haven_manager.html#a0775f430c3910c855f23c9e53a535556',1,'PlayHavenManager']]]
];
