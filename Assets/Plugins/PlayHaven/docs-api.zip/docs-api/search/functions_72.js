var searchData=
[
  ['registerforpushnotifications',['RegisterForPushNotifications',['../class_play_haven_manager.html#acfe6a343de1b315248d9f5ffda8bdc8e',1,'PlayHavenManager']]],
  ['request',['Request',['../class_play_haven_1_1_play_haven_content_requester.html#a40fb391cf905b23e78161f76472759e2',1,'PlayHaven.PlayHavenContentRequester.Request()'],['../class_play_haven_1_1_play_haven_content_requester.html#a5c4e62cd52305423a964904659f7d6c4',1,'PlayHaven.PlayHavenContentRequester.Request(bool refetch)']]],
  ['requestcompletedhandler',['RequestCompletedHandler',['../namespace_play_haven.html#a0ca7a0bc51bd9361f54de2372cb18ed6',1,'PlayHaven']]],
  ['rewardhandler',['RewardHandler',['../class_play_haven_manager.html#a3da9bca26ee2a17054c4ef8263e77ed4',1,'PlayHavenManager']]],
  ['rewardtriggerhandler',['RewardTriggerHandler',['../namespace_play_haven.html#a8dbe3d78da3f36ee4ff37a14591ddf5a',1,'PlayHaven']]]
];
