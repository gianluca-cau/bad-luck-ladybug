var searchData=
[
  ['cancelrequesthandler',['CancelRequestHandler',['../class_play_haven_manager.html#a4ee670c69266b72a26da610b6ea6887a',1,'PlayHavenManager']]],
  ['clearbadge',['ClearBadge',['../class_play_haven_manager.html#a1c8c2012d77b9fc203f067121a5dd657',1,'PlayHavenManager']]],
  ['contentpreloadrequest',['ContentPreloadRequest',['../class_play_haven_manager.html#a87b57eb36acc2ed8b180b6407c603004',1,'PlayHavenManager']]],
  ['contentrequest',['ContentRequest',['../class_play_haven_manager.html#a457076c4951586ed5aba1ab2882645fe',1,'PlayHavenManager.ContentRequest(string placement)'],['../class_play_haven_manager.html#aef40de38bc3590282efbc291bb47ec7e',1,'PlayHavenManager.ContentRequest(string placement, bool showsOverlayImmediately)']]]
];
