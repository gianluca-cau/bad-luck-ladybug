var searchData=
[
  ['whentogetnotifications',['whenToGetNotifications',['../class_play_haven_manager.html#a506f4580733c2115bb4b5fbfe46fa00c',1,'PlayHavenManager.whenToGetNotifications()'],['../class_play_haven_manager.html#ae80f3675e48de15b6b47828993edcef8',1,'PlayHavenManager.WhenToGetNotifications()']]],
  ['whentoopen',['WhenToOpen',['../class_play_haven_manager.html#a855cadcaacef4d8d1f2b9ffae2e1a981',1,'PlayHavenManager']]],
  ['whentoregisterforpushnotifications',['WhenToRegisterForPushNotifications',['../class_play_haven_manager.html#a14a179a4259fff3038618464359ef07c',1,'PlayHavenManager']]],
  ['whentorequest',['whenToRequest',['../class_play_haven_1_1_play_haven_content_requester.html#ac432197342d1ee806699a3fdc61b4405',1,'PlayHaven.PlayHavenContentRequester.whenToRequest()'],['../class_play_haven_1_1_play_haven_content_requester.html#a4fd5662a9a85d9d4d643506faf972424',1,'PlayHaven.PlayHavenContentRequester.WhenToRequest()']]],
  ['whentosendopen',['whenToSendOpen',['../class_play_haven_manager.html#a6097a56e7950487053d4c60b5b46d8e3',1,'PlayHavenManager']]],
  ['wifiandcarriernetwork',['WiFiAndCarrierNetwork',['../class_play_haven_1_1_play_haven_content_requester.html#ad02e8ddbc94cc6e0858dc76d91626e83aba0283edb62bd1f971ace330979aea60',1,'PlayHaven::PlayHavenContentRequester']]],
  ['wifionly',['WiFiOnly',['../class_play_haven_1_1_play_haven_content_requester.html#ad02e8ddbc94cc6e0858dc76d91626e83aabb3b10910736498a05fbda05bc01525',1,'PlayHaven::PlayHavenContentRequester']]],
  ['willdisplaycontenthandler',['WillDisplayContentHandler',['../namespace_play_haven.html#a50dc7d73010a55e9741b3be6a995c1f6',1,'PlayHaven']]]
];
