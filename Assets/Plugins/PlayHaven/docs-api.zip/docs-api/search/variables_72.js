var searchData=
[
  ['receipt',['receipt',['../class_play_haven_1_1_reward.html#a0d52d448cae08f54ffa8fb8cf2d805fc',1,'PlayHaven.Reward.receipt()'],['../class_play_haven_1_1_purchase.html#a02b2b32e8228b430065f29b8defa48e2',1,'PlayHaven.Purchase.receipt()']]],
  ['refetchwhenused',['refetchWhenUsed',['../class_play_haven_1_1_play_haven_content_requester.html#a95206b296a3ef4641844358f8d86b0a6',1,'PlayHaven::PlayHavenContentRequester']]],
  ['requestdelay',['requestDelay',['../class_play_haven_1_1_play_haven_content_requester.html#a4633271d68a598f0fd0fad00c9699b61',1,'PlayHaven::PlayHavenContentRequester']]],
  ['rewardmaybedelivered',['rewardMayBeDelivered',['../class_play_haven_1_1_play_haven_content_requester.html#a0530f68e7c85dd8df0caa6d2eaf4b901',1,'PlayHaven::PlayHavenContentRequester']]],
  ['rewardmessagetype',['rewardMessageType',['../class_play_haven_1_1_play_haven_content_requester.html#a31fb59dbb68751d7229dd3da676745ec',1,'PlayHaven::PlayHavenContentRequester']]]
];
