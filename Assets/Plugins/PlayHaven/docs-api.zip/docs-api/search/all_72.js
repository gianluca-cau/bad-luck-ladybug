var searchData=
[
  ['receipt',['receipt',['../class_play_haven_1_1_reward.html#a0d52d448cae08f54ffa8fb8cf2d805fc',1,'PlayHaven.Reward.receipt()'],['../class_play_haven_1_1_purchase.html#a02b2b32e8228b430065f29b8defa48e2',1,'PlayHaven.Purchase.receipt()']]],
  ['refetchwhenused',['refetchWhenUsed',['../class_play_haven_1_1_play_haven_content_requester.html#a95206b296a3ef4641844358f8d86b0a6',1,'PlayHaven::PlayHavenContentRequester']]],
  ['registerforpushnotifications',['RegisterForPushNotifications',['../class_play_haven_manager.html#acfe6a343de1b315248d9f5ffda8bdc8e',1,'PlayHavenManager']]],
  ['request',['Request',['../class_play_haven_1_1_play_haven_content_requester.html#a40fb391cf905b23e78161f76472759e2',1,'PlayHaven.PlayHavenContentRequester.Request()'],['../class_play_haven_1_1_play_haven_content_requester.html#a5c4e62cd52305423a964904659f7d6c4',1,'PlayHaven.PlayHavenContentRequester.Request(bool refetch)']]],
  ['requestcompletedhandler',['RequestCompletedHandler',['../namespace_play_haven.html#a0ca7a0bc51bd9361f54de2372cb18ed6',1,'PlayHaven']]],
  ['requestdelay',['requestDelay',['../class_play_haven_1_1_play_haven_content_requester.html#a4633271d68a598f0fd0fad00c9699b61',1,'PlayHaven::PlayHavenContentRequester']]],
  ['requestid',['RequestId',['../class_play_haven_1_1_play_haven_content_requester.html#a78f387eb7d65928e66e26b4ff7ac3626',1,'PlayHaven::PlayHavenContentRequester']]],
  ['requesttype',['RequestType',['../namespace_play_haven.html#aac76f50c8e062fce56e0f33a923f3760',1,'PlayHaven']]],
  ['reward',['Reward',['../class_play_haven_1_1_reward.html',1,'PlayHaven']]],
  ['reward',['Reward',['../namespace_play_haven.html#aa6ff3a1cd7108c9da64cb23a33e9d1b8a35281ac0e8d77e142fdcd41c07ce47dd',1,'PlayHaven']]],
  ['rewardhandler',['RewardHandler',['../class_play_haven_manager.html#a3da9bca26ee2a17054c4ef8263e77ed4',1,'PlayHavenManager']]],
  ['rewardmaybedelivered',['rewardMayBeDelivered',['../class_play_haven_1_1_play_haven_content_requester.html#a0530f68e7c85dd8df0caa6d2eaf4b901',1,'PlayHaven::PlayHavenContentRequester']]],
  ['rewardmessagetype',['rewardMessageType',['../class_play_haven_1_1_play_haven_content_requester.html#a31fb59dbb68751d7229dd3da676745ec',1,'PlayHaven::PlayHavenContentRequester']]],
  ['rewardtriggerhandler',['RewardTriggerHandler',['../namespace_play_haven.html#a8dbe3d78da3f36ee4ff37a14591ddf5a',1,'PlayHaven']]]
];
