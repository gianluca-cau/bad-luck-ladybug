var searchData=
[
  ['badgemoregamesplacement',['badgeMoreGamesPlacement',['../class_play_haven_manager.html#adcdbfd6baab0e7895fc73a7869f73436',1,'PlayHavenManager']]]
];
