var searchData=
[
  ['badgeupdatehandler',['BadgeUpdateHandler',['../namespace_play_haven.html#a43b87fa413d35e2a2a653f0e2202761c',1,'PlayHaven']]]
];
