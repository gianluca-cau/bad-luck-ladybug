var searchData=
[
  ['defaultshowsoverlayimmediately',['defaultShowsOverlayImmediately',['../class_play_haven_manager.html#a3c8182089c2512c9222234d8ee9b6c1f',1,'PlayHavenManager']]],
  ['defaulttestrewardname',['defaultTestRewardName',['../class_play_haven_1_1_play_haven_content_requester.html#a5b0b853787c12fada9df136561389ec6',1,'PlayHaven::PlayHavenContentRequester']]],
  ['defaulttestrewardquantity',['defaultTestRewardQuantity',['../class_play_haven_1_1_play_haven_content_requester.html#a25e19f280cae41bb4361b871f9cd77c3',1,'PlayHaven::PlayHavenContentRequester']]],
  ['deregisterfrompushnofications',['DeregisterFromPushNofications',['../class_play_haven_manager.html#ac0400acf0c3b09daa7466a8025a96ce0',1,'PlayHavenManager']]],
  ['description',['description',['../class_play_haven_1_1_error.html#a99b872035eec31bc143ae0abcb9c64dd',1,'PlayHaven::Error']]],
  ['destroygameobject',['DestroyGameObject',['../class_play_haven_1_1_play_haven_content_requester.html#ac8ba95d9138891c6d543c9c6490ebf69a9781cba74eb3143dc6deb1fc7fa05ff7',1,'PlayHaven::PlayHavenContentRequester']]],
  ['destroyroot',['DestroyRoot',['../class_play_haven_1_1_play_haven_content_requester.html#ac8ba95d9138891c6d543c9c6490ebf69a4ade62181fc31cdd5f29edb4226085a8',1,'PlayHaven::PlayHavenContentRequester']]],
  ['destroyself',['DestroySelf',['../class_play_haven_1_1_play_haven_content_requester.html#ac8ba95d9138891c6d543c9c6490ebf69a0306364c3bd9659e89ab1d026f7b7534',1,'PlayHaven::PlayHavenContentRequester']]],
  ['diddisplaycontenthandler',['DidDisplayContentHandler',['../namespace_play_haven.html#a11acd4b749eb926be5836f5a87fb4144',1,'PlayHaven']]],
  ['disabled',['Disabled',['../class_play_haven_manager.html#ae80f3675e48de15b6b47828993edcef8ab9f5c797ebbf55adccdd8539a65a0241',1,'PlayHavenManager.Disabled()'],['../class_play_haven_manager.html#a14a179a4259fff3038618464359ef07cab9f5c797ebbf55adccdd8539a65a0241',1,'PlayHavenManager.Disabled()']]],
  ['dismisshandler',['DismissHandler',['../class_play_haven_manager.html#abc239c38900cff9020c57323a7d85e0a',1,'PlayHavenManager.DismissHandler()'],['../namespace_play_haven.html#a2d8917cac3f9a2235a22915475dfaa72',1,'PlayHaven.DismissHandler()']]],
  ['dismisstype',['DismissType',['../namespace_play_haven.html#aa6ff3a1cd7108c9da64cb23a33e9d1b8',1,'PlayHaven']]],
  ['donotdestroyonload',['doNotDestroyOnLoad',['../class_play_haven_manager.html#aacae4880f07f95b5942e999e5840c4a7',1,'PlayHavenManager']]]
];
