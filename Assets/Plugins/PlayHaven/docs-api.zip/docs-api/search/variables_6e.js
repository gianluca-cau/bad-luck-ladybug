var searchData=
[
  ['name',['name',['../class_play_haven_1_1_reward.html#aabe8c0dbfd7f3ff38f3e0511f5b5bf4c',1,'PlayHaven::Reward']]],
  ['notificationpolldelay',['notificationPollDelay',['../class_play_haven_manager.html#a719aca981e8784b63678b8d3de634db6',1,'PlayHavenManager']]],
  ['notificationpollrate',['notificationPollRate',['../class_play_haven_manager.html#abcd6fb6dd1445f3ed2f38a2dec99bcc6',1,'PlayHavenManager']]]
];
