var annotated =
[
    [ "PlayHaven", "namespace_play_haven.html", "namespace_play_haven" ],
    [ "PlayHavenManager", "class_play_haven_manager.html", "class_play_haven_manager" ]
];