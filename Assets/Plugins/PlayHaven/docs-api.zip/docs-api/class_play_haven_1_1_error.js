var class_play_haven_1_1_error =
[
    [ "ToString", "class_play_haven_1_1_error.html#ab103a9f3e8ff9b1823ec9f26cefa2615", null ],
    [ "code", "class_play_haven_1_1_error.html#a6ef41e95d72c0b9c638f80329ee688f2", null ],
    [ "description", "class_play_haven_1_1_error.html#a99b872035eec31bc143ae0abcb9c64dd", null ]
];