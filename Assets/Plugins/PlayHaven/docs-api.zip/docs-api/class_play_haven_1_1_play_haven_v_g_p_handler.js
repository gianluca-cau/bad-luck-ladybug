var class_play_haven_1_1_play_haven_v_g_p_handler =
[
    [ "PurchaseEventHandler", "class_play_haven_1_1_play_haven_v_g_p_handler.html#a621a0af652b7353a8800e2cc770d83a0", null ],
    [ "OnPurchasePresented", "class_play_haven_1_1_play_haven_v_g_p_handler.html#a7891c26f19d89a8eec59bda7d47cc44c", null ]
];