var hierarchy =
[
    [ "PlayHaven.Error", "class_play_haven_1_1_error.html", null ],
    [ "PlayHavenManager.IPlayHavenRequest", "interface_play_haven_manager_1_1_i_play_haven_request.html", null ],
    [ "PlayHaven.MiniJSON", "class_play_haven_1_1_mini_j_s_o_n.html", null ],
    [ "PlayHaven.PlayHavenContentRequester", "class_play_haven_1_1_play_haven_content_requester.html", null ],
    [ "PlayHavenManager", "class_play_haven_manager.html", null ],
    [ "PlayHaven.PlayHavenVGPHandler", "class_play_haven_1_1_play_haven_v_g_p_handler.html", null ],
    [ "PlayHaven.Purchase", "class_play_haven_1_1_purchase.html", null ],
    [ "PlayHaven.Reward", "class_play_haven_1_1_reward.html", null ]
];