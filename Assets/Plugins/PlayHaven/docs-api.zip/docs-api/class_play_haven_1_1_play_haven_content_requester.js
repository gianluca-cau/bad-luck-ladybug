var class_play_haven_1_1_play_haven_content_requester =
[
    [ "ExhaustedAction", "class_play_haven_1_1_play_haven_content_requester.html#ac8ba95d9138891c6d543c9c6490ebf69", [
      [ "None", "class_play_haven_1_1_play_haven_content_requester.html#ac8ba95d9138891c6d543c9c6490ebf69a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "DestroySelf", "class_play_haven_1_1_play_haven_content_requester.html#ac8ba95d9138891c6d543c9c6490ebf69a0306364c3bd9659e89ab1d026f7b7534", null ],
      [ "DestroyGameObject", "class_play_haven_1_1_play_haven_content_requester.html#ac8ba95d9138891c6d543c9c6490ebf69a9781cba74eb3143dc6deb1fc7fa05ff7", null ],
      [ "DestroyRoot", "class_play_haven_1_1_play_haven_content_requester.html#ac8ba95d9138891c6d543c9c6490ebf69a4ade62181fc31cdd5f29edb4226085a8", null ]
    ] ],
    [ "InternetConnectivity", "class_play_haven_1_1_play_haven_content_requester.html#ad02e8ddbc94cc6e0858dc76d91626e83", [
      [ "WiFiOnly", "class_play_haven_1_1_play_haven_content_requester.html#ad02e8ddbc94cc6e0858dc76d91626e83aabb3b10910736498a05fbda05bc01525", null ],
      [ "CarrierNetworkOnly", "class_play_haven_1_1_play_haven_content_requester.html#ad02e8ddbc94cc6e0858dc76d91626e83ad5e7338113aa8632869ec0b3286ac22d", null ],
      [ "WiFiAndCarrierNetwork", "class_play_haven_1_1_play_haven_content_requester.html#ad02e8ddbc94cc6e0858dc76d91626e83aba0283edb62bd1f971ace330979aea60", null ],
      [ "Always", "class_play_haven_1_1_play_haven_content_requester.html#ad02e8ddbc94cc6e0858dc76d91626e83a68eec46437c384d8dad18d5464ebc35c", null ]
    ] ],
    [ "MessageType", "class_play_haven_1_1_play_haven_content_requester.html#ad71df161cab935fe4a04d873bb83ba77", [
      [ "None", "class_play_haven_1_1_play_haven_content_requester.html#ad71df161cab935fe4a04d873bb83ba77a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Send", "class_play_haven_1_1_play_haven_content_requester.html#ad71df161cab935fe4a04d873bb83ba77a94966d90747b97d1f0f206c98a8b1ac3", null ],
      [ "Broadcast", "class_play_haven_1_1_play_haven_content_requester.html#ad71df161cab935fe4a04d873bb83ba77abe55b6387170df0ca68f41225268e842", null ],
      [ "Upwards", "class_play_haven_1_1_play_haven_content_requester.html#ad71df161cab935fe4a04d873bb83ba77a745f420b489cbb70c8aed15b030f21ac", null ]
    ] ],
    [ "WhenToRequest", "class_play_haven_1_1_play_haven_content_requester.html#a4fd5662a9a85d9d4d643506faf972424", [
      [ "Awake", "class_play_haven_1_1_play_haven_content_requester.html#a4fd5662a9a85d9d4d643506faf972424a9ca8bcac74fbf1f118cc3589aeca836f", null ],
      [ "Start", "class_play_haven_1_1_play_haven_content_requester.html#a4fd5662a9a85d9d4d643506faf972424aa6122a65eaa676f700ae68d393054a37", null ],
      [ "OnEnable", "class_play_haven_1_1_play_haven_content_requester.html#a4fd5662a9a85d9d4d643506faf972424a85979b34818def5b59afd4ffb1e32f99", null ],
      [ "OnDisable", "class_play_haven_1_1_play_haven_content_requester.html#a4fd5662a9a85d9d4d643506faf972424a44a75b848d7812073e63189bac6ea229", null ],
      [ "Manual", "class_play_haven_1_1_play_haven_content_requester.html#a4fd5662a9a85d9d4d643506faf972424ae1ba155a9f2e8c3be94020eef32a0301", null ]
    ] ],
    [ "GiveReward", "class_play_haven_1_1_play_haven_content_requester.html#a46ab9ac4ba84c2a84c6dfd738e41c3b1", null ],
    [ "PreFetch", "class_play_haven_1_1_play_haven_content_requester.html#aabe99aeb212b9e4c80417862dfdf0961", null ],
    [ "Request", "class_play_haven_1_1_play_haven_content_requester.html#a40fb391cf905b23e78161f76472759e2", null ],
    [ "Request", "class_play_haven_1_1_play_haven_content_requester.html#a5c4e62cd52305423a964904659f7d6c4", null ],
    [ "connectionForPrefetch", "class_play_haven_1_1_play_haven_content_requester.html#a318010da704db3bc351ec2fe221acad5", null ],
    [ "defaultTestRewardName", "class_play_haven_1_1_play_haven_content_requester.html#a5b0b853787c12fada9df136561389ec6", null ],
    [ "defaultTestRewardQuantity", "class_play_haven_1_1_play_haven_content_requester.html#a25e19f280cae41bb4361b871f9cd77c3", null ],
    [ "exhaustAction", "class_play_haven_1_1_play_haven_content_requester.html#a84b6b924e63ecd6b0c9bdadd64f2e307", null ],
    [ "limitedUse", "class_play_haven_1_1_play_haven_content_requester.html#a2006095e301ed30534ffd21b033a5b73", null ],
    [ "maxUses", "class_play_haven_1_1_play_haven_content_requester.html#aa5d8d680ac8a6acc95b83f41f69fa6a9", null ],
    [ "placement", "class_play_haven_1_1_play_haven_content_requester.html#a09b4e9dfc7de93c83c0c3befe593f9ec", null ],
    [ "prefetch", "class_play_haven_1_1_play_haven_content_requester.html#a59b0f3958291c375f25847e3a825a700", null ],
    [ "refetchWhenUsed", "class_play_haven_1_1_play_haven_content_requester.html#a95206b296a3ef4641844358f8d86b0a6", null ],
    [ "requestDelay", "class_play_haven_1_1_play_haven_content_requester.html#a4633271d68a598f0fd0fad00c9699b61", null ],
    [ "rewardMayBeDelivered", "class_play_haven_1_1_play_haven_content_requester.html#a0530f68e7c85dd8df0caa6d2eaf4b901", null ],
    [ "rewardMessageType", "class_play_haven_1_1_play_haven_content_requester.html#a31fb59dbb68751d7229dd3da676745ec", null ],
    [ "showsOverlayImmediately", "class_play_haven_1_1_play_haven_content_requester.html#abf42f206fa269a3785593b5c45779a12", null ],
    [ "useDefaultTestReward", "class_play_haven_1_1_play_haven_content_requester.html#ab25882c1d258e82a1c798beba2afa197", null ],
    [ "whenToRequest", "class_play_haven_1_1_play_haven_content_requester.html#ac432197342d1ee806699a3fdc61b4405", null ],
    [ "IsExhausted", "class_play_haven_1_1_play_haven_content_requester.html#a3bbbdff8c0531af90f6e294b7ab543c5", null ],
    [ "RequestId", "class_play_haven_1_1_play_haven_content_requester.html#a78f387eb7d65928e66e26b4ff7ac3626", null ]
];