var class_play_haven_1_1_purchase =
[
    [ "ToString", "class_play_haven_1_1_purchase.html#a2a14eebc03fb619d95ef06cbc23132a7", null ],
    [ "orderId", "class_play_haven_1_1_purchase.html#a522b8e02b033ea163877ece599455b70", null ],
    [ "price", "class_play_haven_1_1_purchase.html#a7543201728add2b90bd15e3c0b3eb2c4", null ],
    [ "productIdentifier", "class_play_haven_1_1_purchase.html#a8758121269de9678e43c2f65d89ff6e5", null ],
    [ "quantity", "class_play_haven_1_1_purchase.html#a72e972c438c14596f5d1a4c43259b83f", null ],
    [ "receipt", "class_play_haven_1_1_purchase.html#a02b2b32e8228b430065f29b8defa48e2", null ],
    [ "store", "class_play_haven_1_1_purchase.html#a9a151ca70741a6cb466346e5ce91bfaf", null ]
];